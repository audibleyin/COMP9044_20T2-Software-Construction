#!/bin/sh

grep '^[0-9].*[^0-9]$' input