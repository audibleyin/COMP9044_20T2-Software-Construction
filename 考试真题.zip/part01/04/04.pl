# write a program that reads lines of text from its standard input 
# and if a line contains two or more integers it swaps the first and second integer.

# if a line contains less than two integers it should be printed unchanged
# if a line contians more than two integers only the first and second integer should be changed

# And the first 24 shall become 42 last
# 1 is the loneliest number
# Some lines have no numbers
# somelines23have43numbers567butnospaces
# Powers of 10 are:1 10 100 1000
# The answer is 42
# 6 * 7 = 42

# And the first 42 shall become 24 last
# 1 is the loneliest number
# Some lines have no numbers
# somelines43have23numbers567butnospaces
# Powers of 1 are:10 10 100 1000
# The answer is 42
# 7 * 6 = 42

