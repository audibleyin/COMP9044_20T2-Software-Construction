#!/usr/bin/perl -w

# ./05.pl 
# 
# ./05.pl 42
#42

# ./05.pl forty two 42
#42

# ./05.pl three 3 one hundred 100 forty two 42
#3 42 100

# ./05.pl 9 10 9 42 10 100 5
#5 9 9 10 10 42 100

# ./05.pl 10 b52 7up z0ne 3
#3 10