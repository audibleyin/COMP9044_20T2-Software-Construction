#/usr/bin/perl -w

#./06.pl aaa723bbb aaa727bbb
#aaa723bbb
#aaa724bbb
#aaa725bbb
#aaa726bbb
#aaa727bbb

#./06.pl bell11 bell15
#bell11
#bell12
#bell13
#bell14
#bell15

#./06.pl 6th 9th
#6th
#7th
#8th
#9th

#./06.pl 13 14
#13
#14

#./06.pl ans42er ans42er
#ans42er