#!/bin/sh
egrep '[^0-9]$' input