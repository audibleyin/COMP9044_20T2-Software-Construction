#!/usr/bin/perl -w

@a = <STDIN>;
$b = @a;
print "$b\n";