#!/usr/bin/perl -w
$email = "ken@gmail.com";
@a = split(/\./, $email);
print "@a\n";