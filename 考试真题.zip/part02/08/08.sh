#!/bin/sh

cat data|sort| uniq -c |sort -n