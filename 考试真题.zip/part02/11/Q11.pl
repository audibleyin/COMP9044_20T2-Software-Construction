#!/usr/bin/perl -w

# Write a perl program which taks 0 or more arguments and prints some of those arguments

# ./q11.pl
# 
# ./q11.pl 42
# 42
# ./q11.pl three 3 one hundred 100 forty two 42
# 3 42 100
# ./q11.pl 9 10 9 42 10 100 5
# 5 9 9 10 10 42 100
# ./q11.pl 10 b52 7up z0ne 3
# 3 10