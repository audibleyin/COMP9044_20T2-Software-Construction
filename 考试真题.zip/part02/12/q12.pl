#!/usr/bin/perl -w

# Write a Perl program that reads lines of text from its standard input 
# and prints the line which contians the largest initial integer
# ./q12.pl < number_lines1.txt
#The answer is 42.
# ./q12.pl < number_lines2.txt
#3 is a common number
#3 2 1
#Three3two2one1