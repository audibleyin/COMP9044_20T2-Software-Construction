#!/usr/bin/perl -w
# write a program that read positive integers from standard input.
# Your program will receive the integers from n to m with one integer missing
# the integers will not be ordered. It shoud print the missing number
# 39 45 40 44 41 43

# 42


# 6 8 9 1 
#  7  2
# 
# 3 10 1 12
# 5

# 4

# 1006 1004 
# 1003 1007
# 1008 1009

# 1005